export interface Paciente {
    id: number;
    nombre: string;
    apellido: string;
    fechaNacimiento: string; 
    telefono: string;
}