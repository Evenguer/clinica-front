// src/App.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Paciente } from './types';
import PacienteForm from './componente/PacienteForm';
import PacienteTable from './componente/PacienteTable';
const App: React.FC = () => {
  // Estado para almacenar la lista de pacientes
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  // Estado para almacenar el paciente que se está editando
  const [pacienteEdit, setPacienteEdit] = useState<Paciente | null>(null);

  // Hook que se ejecuta una vez al mostrar el componente para obtener la lista de pacientes
  useEffect(() => {
    obtenerPacientes();
  }, []);

  // Función para obtener la lista de pacientes desde el Backend
  const obtenerPacientes = async () => {
    try {
      // Hace una solicitud GET a la API de pacientes /api/pacientes
      const respuesta = await axios.get('/api/clinicadental/pacientes');
      // Actualiza el estado (Información de los pacientes)
      setPacientes(respuesta.data);
    } catch (error) {
      // Muestra el error
      console.error(error);
    }
  };

  // Función para manejar la creación de un nuevo paciente
  const manejarCrear = async (paciente: Omit<Paciente, 'id'>) => {
    try {
      // Hace una solicitud POST a la API de pacientes /api/pacientes
      await axios.post('/api/clinicadental/pacientes', paciente);
      // Obtiene la lista de pacientes actualizada
      obtenerPacientes();
    } catch (error) {
      // Muestra el error en la consola
      console.error(error);
    }
  };

  // Función para manejar la actualización de un paciente
  const manejarActualizar = async (paciente: Omit<Paciente, 'id'>) => {
    // Si no hay paciente para editar, no hace nada
    if (!pacienteEdit) return;
    try {
      // Hace una solicitud PUT a la API de pacientes /api/pacientes
      await axios.put(`/api/clinicadental/pacientes/${pacienteEdit.id}`, paciente);
      // Obtiene la lista de pacientes actualizada
      obtenerPacientes();
      setPacienteEdit(null);
    } catch (error) {
      // Muestra el error en la consola
      console.error(error);
    }
  };

  // Función para manejar la eliminación de un paciente
  const manejarEliminar = async (id: number) => {
    try {
      // Hace una solicitud DELETE a la API de pacientes /api/pacientes
      await axios.delete(`/api/clinicadental/pacientes/${id}`);
      // Obtiene la lista de pacientes actualizada
      obtenerPacientes();
    } catch (error) {
      // Muestra el error en la consola
      console.error(error);
    }
  };

  // Función para iniciar la edición de un paciente
  const iniciarEdicion = (paciente: Paciente) => {
    // Establece el paciente que se está editando
    setPacienteEdit(paciente);
  };

  // Función para cancelar la edición reseteando el paciente que se está editando
  const cancelarEdicion = () => {
    // Limpiar el paciente que se está editando (resetea)
    setPacienteEdit(null);
  };

  return (
    <div className="container-academico">

      <h1>Gestión de Pacientes</h1>
      <PacienteForm
        onSubmit={pacienteEdit ? manejarActualizar : manejarCrear}
        initialData={pacienteEdit || undefined}
        onCancel={pacienteEdit ? cancelarEdicion : undefined}
      />
      <PacienteTable
        pacientes={pacientes}
        onEdit={iniciarEdicion}
        onDelete={manejarEliminar}
      />
    </div>
  );
};

export default App;