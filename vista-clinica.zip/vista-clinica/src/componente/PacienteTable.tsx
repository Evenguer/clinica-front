import React from 'react';
import { Paciente } from '../types';

// Definimos las propiedades que recibirá este componente
interface PacienteTableProps {
    // Lista de pacientes
    pacientes: Paciente[]; // Lista de pacientes a mostrar
    onEdit: (paciente: Paciente) => void; // Función cuando se edite
    onDelete: (id: number) => void; // Función para eliminar al paciente
}

// Definimos el componente funcional PacienteTable
const PacienteTable: React.FC<PacienteTableProps> = ({ pacientes, onEdit, onDelete }) => {
    return (
        <table
            border={1}
            cellPadding={10}
            cellSpacing={0}
            style={{ width: '100%', textAlign: 'center' }}
        >
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Fecha de Nacimiento</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                {pacientes.map((paciente) => (
                    <tr key={paciente.id}>
                        {/* Muestra cada campo del paciente en una celda */}
                        <td>{paciente.id}</td>
                        <td>{paciente.nombre}</td>
                        <td>{paciente.apellido}</td>
                        <td>{paciente.fechaNacimiento}</td>
                        <td>{paciente.telefono}</td>
                        <td>
                            {/* Botón para editar Paciente, llama a onEdit */}
                            <button onClick={() => onEdit(paciente)}>Editar</button>
                            {/* Botón para Eliminar Paciente, llama a onDelete */}
                            {/* Con el id del paciente */}
                            <button
                                onClick={() => onDelete(paciente.id)}
                                style={{ marginLeft: '10px' }}
                            >
                                Eliminar
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default PacienteTable; // Exportamos el componente para su uso en otros archivos