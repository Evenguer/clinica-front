import React, { useState, useEffect } from "react"; // Importamos useState y useEffect
import { Paciente } from "../types"; // Importamos la interfaz Paciente

// Definimos las propiedades que recibirá este componente
interface PacienteFormProps {
    // Función que se ejecutará cuando se envíe el formulario
    onSubmit: (paciente: Omit<Paciente, 'id'>) => void;
    // Datos Iniciales para editar
    initialData?: Paciente;
    // Función para cancelar la edición
    onCancel?: () => void;
}

const PacienteForm: React.FC<PacienteFormProps> = ({ onSubmit, initialData, onCancel }) => {
    // Estados de los campos del formulario
    const [nombre, setNombre] = useState(initialData?.nombre || ''); // Estado para el campo nombre
    const [apellido, setApellido] = useState(initialData?.apellido || ''); // Estado para el campo apellido
    const [fechaNacimiento, setFechaNacimiento] = useState(initialData?.fechaNacimiento || ''); // Estado para el campo fecha de nacimiento
    const [telefono, setTelefono] = useState(initialData?.telefono || ''); // Estado para el campo teléfono

    // Hook que actualiza los campos del formulario cuando se cambia el valor de initialData
    useEffect(() => {
        if (initialData) {
            setNombre(initialData.nombre);
            setApellido(initialData.apellido);
            setFechaNacimiento(initialData.fechaNacimiento);
            setTelefono(initialData.telefono);
        } else {
            setNombre('');
            setApellido('');
            setFechaNacimiento('');
            setTelefono('');
        }
    }, [initialData]);

    // Función que maneja el envío del formulario
    const handleSubmit = (e: React.FormEvent) => {
        // Prevenir el comportamiento por defecto del formulario
        e.preventDefault();
        // Llamar a la función onSubmit con los datos del formulario
        onSubmit({ nombre, apellido, fechaNacimiento, telefono });

        // Si no se está editando, limpiar los campos del formulario después de enviar
        if (!initialData) {
            setNombre('');
            setApellido('');
            setFechaNacimiento('');
            setTelefono('');
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
            {/* Título del formulario que cambia según si se está editando o creando */}
            <h2>{initialData ? 'Editar Paciente' : 'Crear Paciente'}</h2>
            {/* Campo de texto para el nombre */}
            <input
                type="text"
                placeholder="Nombre"
                value={nombre}
                // Actualizar el estado del nombre cuando cambie el valor del campo
                onChange={(e) => setNombre(e.target.value)}
                required // Campo requerido obligatorio
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            {/* Campo de texto para el apellido */}
            <input
                type="text"
                placeholder="Apellido"
                value={apellido}
                // Actualizar el estado del apellido cuando cambie el valor del campo
                onChange={(e) => setApellido(e.target.value)}
                required // Campo requerido obligatorio
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            {/* Campo de texto para la fecha de nacimiento */}
            <input
                type="date"
                placeholder="Fecha de Nacimiento"
                value={fechaNacimiento}
                // Actualizar el estado de la fecha de nacimiento cuando cambie el valor del campo
                onChange={(e) => setFechaNacimiento(e.target.value)}
                required // Campo requerido obligatorio
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            {/* Campo de texto para el teléfono */}
            <input
                type="text"
                placeholder="Teléfono"
                value={telefono}
                // Actualizar el estado del teléfono cuando cambie el valor del campo
                onChange={(e) => setTelefono(e.target.value)}
                required // Campo requerido obligatorio
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            {/* Botón para enviar el formulario */}
            {/* Cambia el texto del botón según si se está editando o creando */}
            <button type="submit">
                {initialData ? 'Actualizar' : 'Crear'}
            </button>
            {/* Botón para cancelar la edición */}
            {/* Muestra el botón solo si se está editando */}
            {initialData && onCancel && (
                <button
                    type="button"
                    onClick={onCancel}
                    style={{ marginLeft: '10px' }}
                >
                    Cancelar
                </button>
            )}
        </form>
    );
};

export default PacienteForm; // Exportamos el componente PacienteForm